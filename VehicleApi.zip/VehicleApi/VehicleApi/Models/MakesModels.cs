﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VehicleApi.Models
{
    public class MakesModels
    {
        public int ID { get; set; }

        public string name { get; set; }

    
      ///  public int ModelnumId { get; set; }

        public string modelsname { get; set; }

      //  public int? makeId { get; set; }

        public int modelId { get; set; }
    }
}
