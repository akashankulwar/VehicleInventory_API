﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WarehouseApi.Models
{
    public class WarehouseModels
    {
        public int WarehouseId { get; set; }
        public string Warehousename { get; set; }
        public int modelidnumber { get; set; }
        public int modelmakeid { get; set; }
        public string modelname { get; set; }
        public int modelId { get; set; }
    }
}
